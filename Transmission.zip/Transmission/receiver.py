import cv2
import socket
import struct
import numpy as np
import open3d as o3d
import sys, termios, tty, os, time
import copy

np.set_printoptions(threshold=sys.maxsize)

HOST = '127.0.0.1'  # The server's hostname or IP address
PORT = 65432      # The port used by the server

class Receiver:
    def __init__(self):
        self.init = True

        self.basePointcloud = o3d.geometry.PointCloud()
        self.basePointcloud_down = o3d.geometry.PointCloud()
        self.iterPointcloud = o3d.geometry.PointCloud()
        self.iterPointcloud_down = o3d.geometry.PointCloud()
        self.voxel_size = 0.01

    def Run(self):

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((HOST, PORT))

            while True:
                # Read message length and unpack it into a bytes object
                raw_depth_len = recvall(s, 4)
                raw_color_len = recvall(s, 4)

                # Reset loop if either bytes object is None
                if not raw_depth_len:
                    continue

                # Unpack bytes object into integer
                depth_msglen = struct.unpack('>I', raw_depth_len)[0]
                color_msglen = struct.unpack('>I', raw_color_len)[0]

                # Use integer to read specified number of bytes from socket for each image type
                depth_data = recvall(s, depth_msglen)
                color_data = recvall(s, color_msglen)

                # Convert to array, then to images to be displayed
                depth_image = np.asarray(bytearray(depth_data), dtype="uint8")
                color_image = np.asarray(bytearray(color_data), dtype="uint8")
                depth_decode = cv2.imdecode(depth_image, cv2.IMREAD_UNCHANGED)
                color_decode = cv2.imdecode(color_image, cv2.IMREAD_COLOR)

                # cv2.imshow('Received',self.color_decode)
                # cv2.waitKey(1)

                # Perform registration
                self.perform_registration(depth_decode, color_decode)

                # Request new frame
                s.send(b"k")



    def perform_registration(self, depth_decode, color_decode):

        # Convert images to numpy arrays
        depth_image = np.asanyarray(depth_decode)
        color_image = np.asanyarray(color_decode)
        img_depth = o3d.geometry.Image(depth_image)
        img_color = o3d.geometry.Image(color_image)

        # Create rgbd image from depth and color images
        rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(img_color, img_depth)
        
        # Gather intrinsics from the profile collected earlier
        pinhole_camera_intrinsic = o3d.camera.PinholeCameraIntrinsic(640, 480, 612.7813110351562, 612.0594482421875, 317.0814208984375, 250.22833251953125)

        # Create pointcloud using the rgbd image and the intrinsics
        self.iterPointcloud = o3d.geometry.PointCloud.create_from_rgbd_image(rgbd_image, pinhole_camera_intrinsic)
        self.iterPointcloud_down = self.iterPointcloud.voxel_down_sample(voxel_size=self.voxel_size)
        self.iterPointcloud_down.transform([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]])

        # If this is first iteration, present base pcd to user
        if self.init:
            print("init")
            o3d.visualization.draw_geometries([self.iterPointcloud])

            char = getch()
            if (char == "r"):
                print("Rejected Base")
                return

            # If user does not reject pcd, set as base
            self.basePointcloud = copy.deepcopy(self.iterPointcloud)
            self.basePointcloud_down = copy.deepcopy(self.iterPointcloud_down)

            self.init = False 

            return

        # Create list of pcds
        pcds_down = []
        pcds_down.append(self.basePointcloud_down)
        pcds_down.append(self.iterPointcloud_down)
        pcds = []
        pcds.append(self.basePointcloud)
        pcds.append(self.iterPointcloud)

        self.iterPointcloud_down.paint_uniform_color([1, 0.706, 0])
        # self.basePointcloud_down.paint_uniform_color([0, 0.651, 0.929])

        # Perform registration
        print("Full registration ...")
        max_correspondence_distance_coarse = self.voxel_size * 15
        max_correspondence_distance_fine = self.voxel_size * 1.5
        with o3d.utility.VerbosityContextManager(
                o3d.utility.VerbosityLevel.Debug) as cm:
            pose_graph = full_registration(self.voxel_size, pcds_down,
                                        max_correspondence_distance_coarse,
                                        max_correspondence_distance_fine)

        # Optimize registration
        print("Optimizing PoseGraph ...")
        option = o3d.registration.GlobalOptimizationOption(
            max_correspondence_distance=max_correspondence_distance_fine,
            edge_prune_threshold=0.25,
            reference_node=0)
        with o3d.utility.VerbosityContextManager(
                o3d.utility.VerbosityLevel.Debug) as cm:
            o3d.registration.global_optimization(
                pose_graph,
                o3d.registration.GlobalOptimizationLevenbergMarquardt(),
                o3d.registration.GlobalOptimizationConvergenceCriteria(),
                option)

        # Display registered pointclouds
        print("Transform points and display")
        for point_id in range(len(pcds)):
            # pcds[point_id].transform(pose_graph.nodes[point_id].pose)
            pcds_down[point_id].transform(pose_graph.nodes[point_id].pose)
        o3d.visualization.draw_geometries(pcds_down)

        # Accept or reject before continuing
        char = getch()
        if (char == "r"):
            print("Rejected Registration")
            return

        # Combine pcds
        comboPointcloud = o3d.geometry.PointCloud()
        for point_id in range(len(pcds)):
            comboPointcloud += pcds_down[point_id]
            print(len(np.asarray(comboPointcloud.points)))

        # Downsample to reduce overlapping pointclouds, set as new basePcd, display
        print("Merge Pointcloud")
        comboPointcloud_down = comboPointcloud.voxel_down_sample(voxel_size=self.voxel_size)
        self.basePointcloud = copy.deepcopy(comboPointcloud)
        o3d.visualization.draw_geometries([self.basePointcloud])

def recvall(sock, n):
    # Helper function to recv n bytes or return None if EOF is hit
    data = bytearray()
    while len(data) < n:
        packet = sock.recv(n - len(data))
        if not packet:
            return None
        data.extend(packet)
    return data

def getch():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
 
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch

def pairwise_registration(voxel_size, source, target, max_correspondence_distance_coarse,
                      max_correspondence_distance_fine):
    print("Apply point-to-plane ICP")
    radius_normal = voxel_size * 2
    source.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=radius_normal, max_nn=30))
    target.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=radius_normal, max_nn=30))

    icp_coarse = o3d.registration.registration_icp(
        source, target, max_correspondence_distance_coarse, np.identity(4),
        o3d.registration.TransformationEstimationPointToPlane())
    icp_fine = o3d.registration.registration_icp(
        source, target, max_correspondence_distance_fine,
        icp_coarse.transformation,
        o3d.registration.TransformationEstimationPointToPlane())
    transformation_icp = icp_fine.transformation
    information_icp = o3d.registration.get_information_matrix_from_point_clouds(
        source, target, max_correspondence_distance_fine,
        icp_fine.transformation)
    return transformation_icp, information_icp


def full_registration(voxel_size, pcds, max_correspondence_distance_coarse,
                      max_correspondence_distance_fine):
    pose_graph = o3d.registration.PoseGraph()
    odometry = np.identity(4)
    pose_graph.nodes.append(o3d.registration.PoseGraphNode(odometry))
    n_pcds = len(pcds)
    for source_id in range(n_pcds):
        for target_id in range(source_id + 1, n_pcds):
            transformation_icp, information_icp = pairwise_registration(
                voxel_size, pcds[source_id], pcds[target_id], max_correspondence_distance_coarse,
                max_correspondence_distance_fine)
            print("Build o3d.registration.PoseGraph")
            if target_id == source_id + 1:  # odometry case
                odometry = np.dot(transformation_icp, odometry)
                pose_graph.nodes.append(
                    o3d.registration.PoseGraphNode(
                        np.linalg.inv(odometry)))
                pose_graph.edges.append(
                    o3d.registration.PoseGraphEdge(source_id,
                                                             target_id,
                                                             transformation_icp,
                                                             information_icp,
                                                             uncertain=False))
            else:  # loop closure case
                pose_graph.edges.append(
                    o3d.registration.PoseGraphEdge(source_id,
                                                             target_id,
                                                             transformation_icp,
                                                             information_icp,
                                                             uncertain=True))
    return pose_graph

if __name__ == "__main__":
    instance = Receiver()
    instance.Run()