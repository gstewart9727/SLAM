import asyncio
import pyrealsense2 as rs
import sys, getopt
import numpy as np
import socket
import struct
import cv2
import open3d as o3d

np.set_printoptions(threshold=sys.maxsize)

HOST = '127.0.0.1'  # Standard loopback interface address (localhost)
PORT = 65432        # Port to listen on (non-privileged ports are > 1023)

def run():
    voxel_size = 0.01


    # Start realsense pipeline
    pipeline, align = openPipeline()

    # Connect to receiver
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        conn, addr = s.accept()
        with conn:
            print('Connected by', addr)
            while True:

                # Get depth and color frame
                depth, color, ts = getDepthAndColor(pipeline, align)

                if not depth or not color:
                    continue

                # Convert frames to numpy arrays
                depth_np = np.asanyarray(depth.get_data())
                color_np = np.asanyarray(color.get_data())

                # Encode the frames
                _, depth_encoded = cv2.imencode('.png', depth_np)
                _, color_encoded = cv2.imencode('.png', color_np)
                # print(depth_encoded)

                depth_data_encoded = np.array(depth_encoded)
                depth_str_encoded = depth_data_encoded.tobytes()
                # print(depth_data_encoded)

                color_data_encoded = np.array(color_encoded)
                color_str_encoded = color_data_encoded.tobytes()

                # Send the data
                msg = struct.pack('>II', len(depth_str_encoded), len(color_str_encoded)) + depth_str_encoded + color_str_encoded
                conn.sendall(msg)

                # Check for response
                ack = conn.recv(1)


def openPipeline():
    cfg = rs.config()
    cfg.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
    cfg.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
    pipeline = rs.pipeline()
    pipeline_profile = pipeline.start(cfg)
    align = rs.align(rs.stream.color)
    sensor = pipeline_profile.get_device().first_depth_sensor()

    return pipeline, align

def getDepthAndColor(pipeline, align):
    # Wait for frames to arrive in pipeline, gather profile from frames
    frames = pipeline.wait_for_frames()
    frames = align.process(frames)
    profile = frames.get_profile()
    depth_frame = frames.get_depth_frame()
    color_frame = frames.get_color_frame()
    timestamp = frames.get_timestamp()

    intrinsics = profile.as_video_stream_profile().get_intrinsics()
    # print(intrinsics.width)
    # print(intrinsics.height)
    # print(intrinsics.fx)
    # print(intrinsics.fy)
    # print(intrinsics.ppx)
    # print(intrinsics.ppy)  

    return depth_frame, color_frame, timestamp


if __name__ == "__main__":
    run()